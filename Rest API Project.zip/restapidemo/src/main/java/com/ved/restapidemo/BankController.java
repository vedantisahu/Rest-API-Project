package com.ved.restapidemo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ved.restapidemo.entities.Account;
import com.ved.restapidemo.services.AccountServices;

@RestController
@RequestMapping("/api")
public class BankController 
{
 @Autowired
AccountServices acserv;
	
@GetMapping("/acc/static")
 public Account getAccountTest()
 {
	 //returns JSON Object
	Account obj=new Account(567,"vedanti","saving",13900);
	return obj;
 }
 
 @GetMapping("/acc/static/multi")
 public ArrayList<Account> getMulti()
 {
	 ArrayList<Account> list= new ArrayList<>();
	 Account a1,a2,a3;
	 a1=new Account(123,"shivani2","current",120000);
	 a2=new Account(323,"Gauri","saving",140000);
	 a3=new Account(423,"Krishna","fixed",130000);
	 list.add(a1);
     list.add(a2);
	 list.add(a3);
	 return list;
 }
 
 @GetMapping("/acc/db/all")
 public ArrayList<Account> getAllAcc()
 {
	ArrayList<Account> list=null;
	list=acserv.getAllAccountData();
	return list;
 }
 
@GetMapping("/acc/search/number/{ano}")
public Account GetAccInfo(@PathVariable int ano)
{
	Account obj=acserv.getAccOnNumber(ano);
	return obj;
}

@GetMapping("acc/search/type/{acctype}")
public ArrayList<Account> GetInfo(@PathVariable String acctype)
{
	ArrayList<Account> list=acserv.getAccOnAccType(acctype);
	
	return list;
}
 //----------------------------------------

@PostMapping("acc/add")
public String addAccount(@RequestBody Account obj)
{
String status=acserv.addNewAccount(obj);
 return status;
 
}
@PutMapping("acc/changebal")
public String modifyBalance(@RequestBody Account obj)
{
	String stat="";
	stat=acserv.chanageBalance(obj);
	return stat;
}

@DeleteMapping("acc/del")
public String delAccount(@RequestParam int ano)
{
	String stat="";
	stat=acserv.deleteAccount(ano);
	return stat;
}
}

package com.ved.restapidemo.services;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.ved.restapidemo.entities.Account;

@Service
public class AccountServices 
{
  public ArrayList<Account> getAllAccountData()
  {
	  ArrayList<Account> list=new ArrayList<>();
	  Connection con;
	  Statement st;
	  ResultSet rs;
	  Account acc; 
	  
	  try
	  {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			st= con.createStatement();
			rs=st.executeQuery("select *from accounts");
			
			while(rs.next())
			{
				acc=new Account();
				acc.setAccno(rs.getInt(1));
				acc.setAccnm(rs.getString("accnm"));
				acc.setAcctype(rs.getString("acctype"));
				acc.setBalance(rs.getFloat(4));
				list.add(acc);

			}
			con.close();
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  
	  return list;
  }
  
  public Account getAccOnNumber(int no)
  {
	  Account acc=new Account();
	  Connection con;
	  PreparedStatement pst;
	  ResultSet rs;
	  
	  try
	  {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
		pst=con.prepareStatement("select *from accounts where accno=?");
		rs=pst.executeQuery();
		if(rs.next())
		{
			acc.setAccno(rs.getInt(1));
			acc.setAccnm(rs.getString("accnm"));
			acc.setAcctype(rs.getString("acctype"));
			acc.setBalance(rs.getFloat(4));	
		}
		else {
			acc.setAccno(no);
			acc.setAccnm("not found");
			acc.setAcctype("not found");
			acc.setBalance(0);		
		}
		con.close();	
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  return acc;
  }
  
  public ArrayList<Account> getAccOnAccType(String type)
  {
	 ArrayList<Account> list=new ArrayList<>();
	 Connection con;
	  PreparedStatement pst;
	  ResultSet rs;
	  Account acc;
	  
	  try
	  {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
		pst=con.prepareStatement("select *from accounts where acctype=?");
		pst.setString(1, type);
		rs=pst.executeQuery();

		while(rs.next())
		{
			acc=new Account();
			acc.setAccno(rs.getInt(1));
			acc.setAccnm(rs.getString("accnm"));
			acc.setAcctype(rs.getString("acctype"));
			acc.setBalance(rs.getFloat(4));
			list.add(acc);

		}
		
		con.close();	
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	 return list;
  }
  
  public String addNewAccount(Account acc)
  {
	  String stat="";
	  Connection con;
	  PreparedStatement pst;
	  try
	  {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
		pst=con.prepareStatement("insert into accounts values(?,?,?,?)");
		pst.setInt(1,acc.getAccno());
		pst.setString(2,acc.getAccnm());
		pst.setString(3,acc.getAcctype());
		pst.setFloat(4,acc.getBalance());
		pst.executeUpdate();
		con.close();
		stat="success";
		
	  }
	  catch(Exception e)
	  {
		  stat="Failed";
		  System.out.println(e);
	  }
	  return stat;
  }
  
  public String chanageBalance(Account acc)
  {
	  String stat="";
	  Connection con;
	  PreparedStatement pst;
	  try
	  {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
		pst=con.prepareStatement("update accounts set balance =? where accno=?");
		
		pst.setFloat(1,acc.getBalance());
		pst.setInt(2,acc.getAccno());
		
		pst.executeUpdate();
		con.close();
		stat="success";
		
	  }
	  catch(Exception e)
	  {
		  stat="Failed";
		  System.out.println(e);
	  }
	  return stat;
  }
  
  public String deleteAccount(int no)
  {
	  {
		  String stat="";
		  Connection con;
		  PreparedStatement pst;
		  try
		  {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("delete from accounts where accno=?");
			
			pst.setInt(1,no);
			int cnt=pst.executeUpdate();
	
			con.close();
			if(cnt>0)
			stat="success";
			else
				stat="Not Found";
			
		  }
		  catch(Exception e)
		  {
			  stat="Failed";
			  System.out.println(e);
		  }
		  return stat;
	  } 
  }
  
}

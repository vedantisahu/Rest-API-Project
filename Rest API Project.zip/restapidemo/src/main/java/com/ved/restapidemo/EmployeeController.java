package com.ved.restapidemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ved.restapidemo.entities.Employee;
import com.ved.restapidemo.services.EmployeeServices;

@RestController
@RequestMapping("/empapi")
public class EmployeeController
{
@Autowired
EmployeeServices empserv;

@PostMapping("/add")
public String addEmp(@RequestBody Employee e)
{
	String stat= "";
	stat=empserv.addNewEmp(e);
	return stat;
}

@PutMapping("/modify")
public String changeEmp(@RequestBody Employee e)
{
	String stat="";
	stat =empserv.modifyEmpData(e);
	return stat;
}
}

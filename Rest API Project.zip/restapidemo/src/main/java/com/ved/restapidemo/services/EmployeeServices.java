package com.ved.restapidemo.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Service;

import com.ved.restapidemo.entities.Employee;


@Service
public class EmployeeServices 
{
	public String addNewEmp(Employee obj)
	  {
		  String stat="";
		  Connection con;
		  PreparedStatement pst;
		  ResultSet rs;
		  try
		  {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("insert into emp values(?,?,?,?,?,?)");
			pst.setInt(1,obj.getEmpno());
			pst.setString(2,obj.getEmpnm());
			pst.setString(3,obj.getDept());
			pst.setString(4,obj.getPost());
			pst.setString(5,obj.getLocation());
			pst.setFloat(6,obj.getSalary());
			pst.executeUpdate();
			con.close();
			stat="success";
			
		  }
		  catch(Exception e)
		  {
			  stat="Failed";
			  System.out.println(e);
		  }
		  return stat;
	  }
	
	public String modifyEmpData(Employee obj)
	{
		String stat="";
		Connection con;
		  PreparedStatement pst;
		  ResultSet rs;
		  try
		  {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("update emp set dept=?,post=?,location=?,salary=? where empno=?");
			pst.setInt(5,obj.getEmpno());
			pst.setString(1,obj.getDept());
			pst.setString(2,obj.getPost());
			pst.setString(3,obj.getLocation());
			pst.setFloat(4,obj.getSalary());
			pst.executeUpdate();
			con.close();
			stat="success";
			
		  }
		  catch(Exception e)
		  {
			  stat="Failed";
			  System.out.println(e);
		  }
		return stat;
	}
}
